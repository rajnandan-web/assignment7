const item=[
    {
      "author": "Chinua Achebe",
      "country": "Nigeria",
      "language": "English",
      "title": "Things Fall Apart",
    },

    {
      "author": "Hans Christian Andersen",
      "country": "Denmark",
      "language": "Danish",
      "title": "Fairy tales",
    },

    {
      "author": "Dante Alighieri",
      "country": "Italy",
      "language": "Italian",
      "title": "The Divine Comedy",
    },

    {
      "author": "Unknown",
      "country": "Sumer and Akkadian Empire",
      "language": "Akkadian",
      "title": "The Epic Of Gilgamesh",
    },

    {
      "author": "Unknown",
      "country": "Achaemenid Empire",
      "language": "Hebrew",
      "title": "The Book Of Job",
    },
  
    {
        "author": "Virginia Woolf",
        "country": "United Kingdom",
        "language": "English",
        "title": "To the Lighthouse",
    },

    {
      "author": "Giovanni Boccaccio",
      "country": "Italy",
      "language": "Italian",
      "title": "The Decameron",
    },

    {
      "author": "Jorge Luis Borges",
      "country": "Argentina",
      "language": "Spanish",
      "title": "Ficciones",
    },
]
export default item;